# TeX i LaTeX

## Co to właściwie jest?

**TeX** jest systemem składu tekstu stworzonym przez Donalda
Knutha\[cite: 1\]. **LaTeX** jest zestawem makr i konwencji zbudowanych
na TeX-u, który znacznie upraszcza przygotowywanie dokumentów\[cite:
1\].

W praktyce użytkownik najczęściej tworzy plik źródłowy `dokument.tex`, a
następnie kompiluje go do postaci pliku wynikowego `dokument.pdf`\[cite:
1\]:
$$\text{źródło (\texttt{*.tex})} \longrightarrow \text{kompilator} \longrightarrow \text{wynik (\texttt{*.pdf})}$$

Nie ustawiamy ręcznie każdej czcionki, numerowania równań czy
odstępów\[cite: 1\]. Opisujemy strukturę dokumentu, a LaTeX zajmuje się
profesjonalnym składem\[cite: 1\].

# Minimalny dokument

Najmniejszy użyteczny dokument ma następującą strukturę\[cite: 2\]:

``` {.latex language="TeX"}
\documentclass{article}
\begin{document}
Hello, LaTeX!
\end{document}
```

## Preambuła i treść dokumentu

Dokument w LaTeX-ie dzieli się na dwie główne części\[cite: 2\]:

- **Preambuła** -- wszystko przed `\begin{document}`\[cite: 2\].
  Ustawiamy tu klasę dokumentu, wgrywamy pakiety oraz definiujemy własne
  komendy\[cite: 2\].

- **Treść dokumentu** -- zawarta między `\begin{document}` a
  `\end{document}`.

# Matematyka

Jednym z największych atutów LaTeX-a jest precyzyjny i estetyczny skład
wzorów matematycznych\[cite: 2\].

## Matematyka w tekście

Wzory wewnątrz akapitu umieszczamy między pojedynczymi dolarami\[cite:
2\]:

- **Źródło:** `Energia dana jest wzorem $E=mc^2$.`\[cite: 2\]

- **Efekt:** Energia dana jest wzorem $E=mc^2$\[cite: 2\].

## Osobne wzory wyśrodkowane

Dla wzorów wyodrębnionych w osobnej linii stosujemy blok `\[ …\]`\[cite:
3\]: $$E = mc^2$$

## Numerowane równania

Używając środowiska `equation`, LaTeX automatycznie doda
numerację\[cite: 3\]: $$\begin{equation}
E = mc^2
\label{eq:energy}
\end{equation}$$

# Odwołania do równań

Ręczne wpisywanie numerów równań (np. „równanie (1)") jest
niepraktyczne\[cite: 3\]. LaTeX automatyzuje ten proces dzięki komendom
`\label` oraz `\ref` (lub `\eqref`)\[cite: 3\].

Przykładowo, korzystając z równania
[\[eq:energy\]](#eq:energy){reference-type="eqref"
reference="eq:energy"}, mamy pewność, że numeracja zaktualizuje się
automatycznie\[cite: 4\].

Dobra praktyka to stosowanie spójnych prefiksów\[cite: 4\]:

`eq:`

:   równanie (np. `eq:energy`)\[cite: 4\]

`fig:`

:   wykres / grafika (np. `fig:fit`)\[cite: 4\]

`tab:`

:   tabela (np. `tab:data`)\[cite: 4\]

`sec:`

:   sekcja (np. `sec:math`)\[cite: 4\]

# Wielowierszowe układy równań

Do wyrównywania wielu równań służy środowisko `align` z pakietu
`amsmath`\[cite: 4\]: $$\begin{align}
x + y &= 5, \\
x - y &= 1.
\end{align}$$

# Macierze

Macierze w nawiasach okrągłych tworzymy za pomocą środowiska
`pmatrix`\[cite: 4\]: $$A = \begin{pmatrix}
2 & 1 \\
1 & 3
\end{pmatrix}$$

# Tabele

Poniżej przedstawiono czytelną tabelę wykonaną z użyciem standardu
`booktabs`\[cite: 5\]:

::: {#tab:data}
   **x**   **y**
  ------- -------
     1       1
     2       4
     3       9

  : Przykładowe dane pomiarowe.
:::

Dane pomiarowe zostały przedstawione w
Tabeli [1](#tab:data){reference-type="ref" reference="tab:data"}\[cite:
5\].

# Grafika

Do wstawiania grafik używamy pakietu `graphicx`\[cite: 5\]:

``` {.latex language="TeX"}
\begin{figure}[h]
\centering
\includegraphics[width=0.7\textwidth]{fit.png}
\caption{Dane i dopasowana prosta.}
\label{fig:fit}
\end{figure}
```

## Formaty plików graficznych

  **Format**   **Typ**     **Zastosowanie**
  ------------ ----------- --------------------------------------------
  **PNG**      Rastrowy    Wykresy, zrzuty ekranu, grafika bezstratna
  **JPG**      Rastrowy    Zdjęcia i obrazki o dużej palecie barw
  **PDF**      Wektorowy   Wykresy naukowe, schematy, diagramy
  **SVG**      Wektorowy   Grafika wektorowa dla WWW

  : Porównanie formatów graficznych.

Dla wykresów naukowych najwyższą jakość zapewnia grafika wektorowa
(**PDF**), ponieważ zachowuje pełną ostrość przy dowolnym
powiększeniu\[cite: 6\].
